package com.example.gridcardviewapp

data class ImgItems(
    var name: String,
    var img: Int,
    var department: String
) {
}
